import FormData from "form-data";

async function processing(urlPath, method) {
    return new Promise((resolve, reject) => {
        let scheme = "https://" + "inferenceengine.vyro.ai/" + method;
        let Form = new FormData();
        Form.append("model_version", 1);
        Form.append("image", Buffer.from(urlPath), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg",
        });
        Form.submit(
            {
                url: scheme,
                headers: {
                    "User-Agent": "okhttp/4.9.3",
                    Connection: "Keep-Alive",
                    "Accept-Encoding": "gzip",
                },
            },
            (err, res) => {
                if (err) return reject(err);
                let data = [];
                res
                    .on("data", (chunk) => data.push(chunk))
                    .on("end", () => resolve(Buffer.concat(data)))
                    .on("error", reject);
            }
        );
    });
}

let handler = async (m, { conn, command }) => {
    // Kirim reaksi awal
    await conn.relayMessage(m.chat, {
        reactionMessage: { key: m.key, text: '⏱️' }
    }, { messageId: m.key.id });

    if (command === "remini") {
        conn.remini = conn.remini || {};
        if (m.sender in conn.remini)
            throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu Sampai Selesai Yah >//<";

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || q.mediaType || "";
        if (!mime) throw `Fotonya Mana Kak?`;
        if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

        conn.remini[m.sender] = true;
        m.reply("Proses Kak...");
        let img = await q.download?.();
        let error;

        try {
            const result = await processing(img, "enhance");
            await conn.sendFile(m.chat, result, "remini.jpg", "Sudah Jadi Kak >//<", m);
        } catch (err) {
            error = true;
        } finally {
            if (error) m.reply("Proses Gagal :(");
            delete conn.remini[m.sender];
            // Kirim reaksi akhir
            await conn.relayMessage(m.chat, {
                reactionMessage: {
                    key: m.key,
                    text: error ? '❌' : '✅'
                }
            }, { messageId: m.key.id });
        }
    }
};

handler.help = ["remini"];
handler.tags = ["main"];
handler.premium = false;
handler.group = false;
handler.limit = true;
handler.command = ["remini"];
handler.limit = true;

export default handler;
/*
SCRIPT BY © VYNAA VALERIE 
•• recode kasih credits 
•• contacts: (t.me/VLShop2)
•• instagram: @vynaa_valerie 
•• (github.com/VynaaValerie) 
*/