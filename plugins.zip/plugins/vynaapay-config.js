export const paymentConfig = {
//isi akun saweria lu
    email: '',
    userID: '',
    name: 'RIKZ',
    prices: {
        3: 2000,      // 3 Hari
        7: 5000,      // 1 Minggu
        14: 10000,    // 2 Minggu
        21: 15000,    // 3 Minggu
        30: 25000,    // 1 Bulan
        60: 40000,    // 2 Bulan
        90: 50000,    // 3 Bulan
        365: 85000,   // 1 Tahun
    },
};
/*
SCRIPT BY © VYNAA VALERIE 
•• recode kasih credits 
•• contacts: (6282389924037)
•• instagram: @vynaa_valerie 
•• (github.com/VynaaValerie) 
*/